# Handoff: Pattadar — property detail redesign

## Overview
Redesign of the property detail screen in Pattadar (land/property records app for Andhra Pradesh & Telangana). It fixes three problems in the current build: the same facts are printed two or three times, the actual land record is missing from the screen, and everything the user can *do* about a gap is invisible.

The redesign is **type-aware**: one shell serves agricultural land, an open plot, and a rented flat. What changes per type is the record fields, the compliance checks, the orderable services, and whether a rent/lease ledger exists.

## About the design files
`Parcel Detail Redesign.dc.html` in this bundle is a **design reference written as HTML** — an interactive prototype showing intended look and behaviour. It is not production code to copy. Recreate it in the app's existing environment (React Native / Swift / Kotlin / Flutter — whatever the app is) using that codebase's established components, navigation and data layer. The property data in the prototype is fixture data.

Open the file in a browser. Three chips above the phone switch property type (this resets prototype state — in the real app they are three different records).

## Fidelity
**High fidelity.** Colours, type sizes, spacing, radii and copy are final-intent. iOS dark-mode system conventions. Recreate pixel-close using the app's existing component library; substitute the platform's native list/sheet primitives where they are equivalent.

---

## 1. What to remove (the duplication fixes)

| Remove | Why | Replace with |
|---|---|---|
| Big title in the nav bar at rest | Repeats the hero title ~40 px below it | Nav centre is **empty at rest**; the title + location fade in (200 ms) only after the content scrolls past 130 px |
| "Held by X" chip in the hero **and** the name again in the Ownership card | Owner stated twice | Holder appears once, in the hero fact strip (avatar + name). The old Ownership card becomes a **title chain** (transfer events only) |
| Acreage in title, hero and ownership row | Stated three times | Extent appears once as a hero fact; recorded-vs-measured comparison lives in The record |
| "Acquired via · Sale" in details and again in the ownership row | Duplicate | Once, in Registration group of The record |
| Four zero-value stat cards + "No photographs yet" empty card | ~40 % of the screen showing zeros | One three-row list: Documents / Open requests / Boundary / Spent — each a count and a chevron |
| "Get it from the office" services inside Documents | Overlaps with site services | All orderable work moves to the new **Requests** tab |

Rule to hold the line: **every fact has exactly one home.** If a value must be visible in two places, the second place shows a link, not the value.

---

## 2. Screens / views

Device: 402 × 874 (iPhone), dark. Content scrolls between a fixed nav bar and a floating tab bar.

### 2.1 Chrome
- **Nav bar** — height 34 px content + 56 px status inset, `rgba(0,0,0,.82)` + `backdrop-filter: blur(18px)`, 1 px bottom hairline `rgba(255,255,255,.07)`.
  - Left: 34 px circular back button, `rgba(255,255,255,.1)`, chevron stroke `#fff` 2 px.
  - Centre: empty until `scrollTop > 130`, then title 15/600 `#fff` + subtitle 11 px `rgba(255,255,255,.45)`.
  - Right: pill `rgba(255,255,255,.1)`, radius 17, containing share and star, both `#0A84FF` (star filled when saved).
- **Tab bar** — floating, inset 12 px, height 66, radius 33, `rgba(28,28,30,.92)` + blur 24, border `rgba(255,255,255,.09)`. Five items: Home, Properties (active `#0A84FF`), File (44 px blue circle `+`, shadow `0 6px 16px rgba(10,132,255,.4)`), Vault, You. Labels 10/600. The centre `+` opens the document scanner.
- **Toast** — bottom 104 px, inset 14, `rgba(38,38,42,.96)` + blur 20, radius 16, green tick, auto-dismiss 2.6 s, enter `toastin` 300 ms.

### 2.2 Hero (identity block)
Margin 14, radius 22, padding 18. Background per type:
- land `linear-gradient(160deg,#4a2f33,#38252a)`
- plot `linear-gradient(160deg,#2f3a4a,#242e3a)`
- flat `linear-gradient(160deg,#2f4438,#22322a)`

Contents: eyebrow 10.5/600 letter-spacing 1.3 `rgba(255,255,255,.55)` (e.g. `AGRICULTURAL · KHATA 567`); title Source Serif 4 34/600, tracking −0.5; two-line location 13 px `rgba(255,255,255,.62)`; a 66 px **readiness ring** on the right (SVG, r 27, stroke 6, track `rgba(255,255,255,.16)`, colour `#FF453A` < 40 %, `#FF9F0A` < 75 %, else `#30D158`; `stroke-dashoffset` transition 700 ms `cubic-bezier(.2,.9,.2,1)`); hairline; then a fact strip of three columns divided by 1 px rules — two type-specific facts (Extent / Class, Extent / Size, Carpet / Floor) and Held by with an 18 px avatar.

Readiness = `done checks / total checks`, rounded. Checks per type:
- land: owner, deed, mutation, ec, tax, map, docno (7 → starts 14 %)
- plot: owner, deed, lrs, tax, fence, map, docno (7)
- flat: owner, deed, oc, tax, society, rentagree (6)

### 2.3 Segmented sub-nav
Horizontally scrolling chips, 8 px gap, padding 8/14, radius 16, 13/600. Active `#fff` on `#000`; idle `rgba(255,255,255,.07)` / `rgba(255,255,255,.6)`. Switching **filters the rendered section** — do not use scroll-to-anchor.

Order: Overview · The record · Documents · Requests · People · On the land (flat: "With the flat") · Rent / Lease (only if tenancy) · Timeline.

### 2.4 Overview
1. **Rent status card** (only if tenancy) — amber `rgba(255,159,10,.12)` border `.28` when overdue, else green `rgba(48,209,88,.1)`. Status eyebrow, amount 19/700, sub line, and two buttons: *Remind* (blue tint) and *Record* (white 10 %).
2. **Needs you** — heading 17/700 + summary "2 blockers · 3 to tidy". Card `rgba(255,255,255,.055)` radius 18, rows 14 px padding, 10 px status dot with a 4 px halo (red `#FF453A` blocker / amber `#FF9F0A` gap / green `#30D158` requested), title 14.5/600, sub 12 px, chevron. Hairline inset 44 px between rows. Overdue rent is the first row when present. Empty state: green tick + "Nothing waiting on you right now."
3. **Cleared strip** — after any fix: green 10 % row "N things cleared today · See record".
4. **Quick actions** — chip row: Document, Boundary, Feature, Request, Beneficiary. `rgba(10,132,255,.13)`, border `.25`, 13/600 `#0A84FF`.
5. **Counts list** — Documents / Open requests / Boundary on the map / Spent on this property. Value right-aligned, colour-coded (`#FF9F0A` when boundary not drawn, `#30D158` when it is).
6. **Activity** — avatar rows, newest first.

### 2.5 The record
Grouped label/value lists (label 13.5 px `rgba(255,255,255,.5)` fixed 130 px, value right-aligned 13.5/500 `#fff`). **A missing value renders as a blue action word** ("Add", "Get EC", "File it", "Link") — tapping opens that field's fix flow. Optional 11.5 px grey hint under a value ("still in the seller's name", "last receipt FY 2022–23").

Groups by type:
- **Land** — Identity (survey no., subdivision, khata/passbook, classification) · Extent (on the record, measured, difference) · Registration (doc number, registered on, SRO, acquired via, consideration) · Clean title checks (encumbrance, land tax, litigation, mutation) · Boundaries (N/S/E/W).
- **Plot** — Identity (plot no., layout, DTCP approval, facing, corner plot) · Extent (record, dimensions, measured, road in front) · Registration · Clean title checks (LRS regularisation, PTIN, EC, litigation) · Neighbours (adjoining plot numbers).
- **Flat** — Identity (flat no., block, floor, facing, parking) · Area (carpet, built-up, super built-up, UDS) · Registration · Clean title checks (OC, RERA, PTIN, share certificate) · Building & bills (association, maintenance, corpus, water).

Then **Where it is** (boundary sources, §3.3) and a link row to On the land.

### 2.6 Documents
Dashed blue drop zone "Scan or upload a document"; filed documents list (PDF thumb, name, meta, green `READ` chip); **Still expected** list — the documents this property type should have but doesn't, each with why it matters and a blue "Get it" that opens the fix sheet.

### 2.7 Requests  *(new)*
- **In progress**: request cards — name, `office · eta · fee`, blue `REQUESTED` chip, a 3-segment progress bar (requested → agent assigned → done), and "Next: an agent is assigned within 24 hours".
- **Papers from the office**: certified deed copy, EC, adangal/pahani, mutation filing, LRS filing, OC chase, share certificate, PTIN linking, rental agreement drafting — per type.
- **Work on the ground**: clear bushes and level, barbed-wire fencing, compound wall quote, corner stones, monthly site photos, weekly watchman, deep clean, tenant police verification, plumbing check, paint quote, inspection visit — per type.
- Footer: "Every request is done by a Pattadar agent, photographed, and filed against this property."

### 2.8 People
Holder card (avatar, name, "You · sole holder since …", 100 %) with the **title chain** beneath as dotted events. Tenant card when a tenancy exists (links to Rent). Beneficiary block — amber, "No beneficiary named" + Add. Groups & partnerships — link to a family group, create a partnership.

### 2.9 On the land / With the flat
Feature rows: 34 px category tile, name 14.5/600, value 12.5 px, right meta ("1 photo", green "NEW"). "Add a feature" row. Below, an **Often forgotten** chip row of unused categories.

Add-feature sheet: 2-column category grid (Water, Power, Markers, Structures, Access, Trees & crop; each shows "N saved" when used) → form with **What to call it** (required) and a category-specific detail field, plus "Add a photo" / "Pin the spot". Save is disabled until the name is non-empty. Entry is named by the user, never by the category.

### 2.10 Rent / Lease  *(flat: monthly, land: yearly)*
- Hero card, tinted by status: eyebrow ("Rent overdue" / "Rent up to date"), amount Source Serif 36/600, sub line, then **Send a reminder** (blue tint) and **Record payment** (solid `#0A84FF`).
- Three stat tiles: collected this lease, deposit held, agreement ends.
- Reminder log line when reminders have been sent.
- **Ledger**: one row per month (or lease year) — dot, period, how it was paid, amount, `PAID` green / `DUE` amber.
- **The agreement**: rent, deposit, lease dates, due day, and "Written agreement" which shows a blue "Draft one" when missing (opens the rental-agreement fix).

### 2.11 Timeline
Single thread with a 1.5 px rail. Year headers in Source Serif 20/600 at 35 % white, shown only when the year changes. Each event: when-eyebrow 11/600 uppercase (must never repeat the year header string), title 14.5/600, sub 12.5 px, optional chip. Dots: done = solid `#30D158` with 3 px halo; past = `rgba(255,255,255,.3)`; future = transparent with 1.5 px **dashed** border.
Content = static history (resurvey / layout approval / purchase) + live user actions + overdue rent + unresolved blockers as future items (`WAITING ON YOU` red / `IN PROGRESS` blue) + the annual tax reminder.

---

## 3. Interactions & behaviour

All sheets: scrim `rgba(0,0,0,.6)` fade 200 ms; sheet `#1C1C1E`, radius 30 top, `upsheet` 300 ms `cubic-bezier(.2,.9,.2,1)`, max-height 88 %, 38×5 grabber. Tapping the scrim closes.

### 3.1 Fix an issue
Row tap → **fix sheet**: severity dot + label ("Blocks a sale or a loan" red / "Worth fixing" amber), title in Source Serif 26, a plain-language *why*, then 2 actions — always one **do it yourself** and one **have Pattadar do it** — plus "Not a problem for me — hide it".

### 3.2 Order a service
Fix action or Requests row → **request sheet**: who does it, fee, usual turnaround, which property; note about the agent; CTA "Confirm · ₹350". On confirm: sheet closes, request enters *In progress*, the issue's row turns green "Requested · we are on it", spend increases, activity + timeline entries are written, toast "Request sent to <office>".

### 3.3 Add a boundary — three routes, all stored
Picker: **Upload the FMB** (tagged BEST, green) / **Walk and mark it** (ON SITE) / **Draw it on the map** (FROM MEMORY). Plus "order a licensed survey · ₹2,500".
- *FMB*: scan animation (sweep 1.1 s + progress) → review "Geo-tags read · 14 tagged corners, 30.02 ac, WGS 84", precision **Survey grade**. For a plot this reads the approved layout drawing instead.
- *Walk*: GPS map with live points and distance, accuracy badge; "Close the shape" disabled under 3 points; result 9 points / 2,214 m / 30.04 ac, precision **±3 m GPS**.
- *Draw*: map **opens centred on the village**, over the cadastral layer; tap to drop corners; gated at 3; result 29.80 ac, precision **From memory**.
Review sheet → "Save this boundary" (or "Make this the primary boundary" / "Keep it as a second reading" once one exists).
Stored in a **sources list** — badge, own name (Resurvey sheet / Walked boundary / Sketched on the map), meta, extent, precision, one flagged `PRIMARY`. With 2+ readings the app states the spread: ≤ 0.5 ac green "agree to within X ac"; above that amber "…usually means a corner is in the wrong place. Worth a licensed survey." Measured extent and the difference vs the record read from the primary source. Saving any source clears the `map` check.

### 3.4 Scan a document
`+` or drop zone → source picker (camera / file / WhatsApp) → scan animation ~800 ms with status copy ("Straightening the pages…", "Reading Telugu and English text…", "Matching it to <property>…") → **Identified**: document title, registration line, and the extracted fields each with a green tick → "Save and fill 4 fields". On save: document filed, its checks cleared, readiness jumps, activity + timeline written.

### 3.5 Rent
- **Remind** → sheet showing the exact message that will be sent, then WhatsApp (green, primary) / SMS / Call, plus "Remind automatically on the 6th, every month".
- **Record payment** → amount prefilled with the outstanding sum, mode chips UPI / Bank transfer / Cash, "Mark as received". The oldest DUE row flips to PAID "Paid today · upi", collected total rises, hero turns green, toast confirms a receipt went to the tenant.

### 3.6 Share
Toggle rows (the record / who holds it / documents / boundary) with iOS switches, then "Copy the link" → toast "Read-only link copied · expires in 7 days".

---

## 4. State

Per property record: `type`, `seg`, `sheet`, `issueId`, `svc`, `scrolled`, `starred`.
Per property data: `fixed[]` (cleared check ids, seeded `['owner']`), `requested[]`, `requests[]`, `docs[]`, `sources[]`, `features[]`, `acts[]`, `ledger[]`, `reminders[]`, `spent`.
Flow-local: `docStep` (0 pick / 1 scanning / 2 found), `scanPct`, `pinStep` (pick / fmb / walk / draw / review), `pend`, `walkPts`, `walkDist`, `drawPts`, `featStep`, `featCat`, `featName`, `featVal`, `payAmount`, `payMode`.

Derived: readiness %, open issues, blocker count, cleared count, primary source, spread between sources, rent dues and collected totals, timeline.

Real implementation notes: readiness must be computed server-side too (it appears in lists); requests need real statuses with agent assignment and photo upload; reminders need an approved WhatsApp template; boundary sources should be stored as GeoJSON with a `precision` and `capturedBy` field and one `isPrimary` per property.

## 5. Design tokens

Colour — background `#000`; canvas outside device `#0a0a0b`; card `rgba(255,255,255,.055)`; card raised `rgba(255,255,255,.07)`; hairline `rgba(255,255,255,.08)`; sheet `#1C1C1E`.
Text — primary `#fff`; secondary `rgba(255,255,255,.5)`; tertiary `rgba(255,255,255,.42)`; quaternary `rgba(255,255,255,.35)`.
Accent — blue `#0A84FF`; red `#FF453A`; amber `#FF9F0A`; green `#30D158`; avatar orange `#E08A3C`; tenant green `#5E8B7E`.
Tints — blue `rgba(10,132,255,.13–.18)`, green `rgba(48,209,88,.10–.15)`, amber `rgba(255,159,10,.10–.12)`.
Category tints — water `rgba(10,132,255,.35)`, power `rgba(255,159,10,.35)`, marker `rgba(142,142,147,.5)`, structure `rgba(191,90,242,.35)`, access `rgba(48,209,88,.3)`, crop `rgba(255,214,10,.3)`.
Type — display **Source Serif 4** 600 (34 hero / 26 sheet / 23 / 20 year); UI system sans: 17 input, 15 sheet action, 14.5 row title, 14 row, 13.5 value, 13 body, 12.5 sub, 12 meta, 11 eyebrow, 10.5 badge, 9.5 chip. Uppercase eyebrows carry 0.6–1.3 px tracking.
Radius — 30 sheet, 26 button, 22 hero, 18 card, 16 inner card, 14 small, 11 tile, 6 chip. Spacing — 14 gutter, 18 section, 22 group heading, 8–9 between cards. Motion — sheets 300 ms `cubic-bezier(.2,.9,.2,1)`; ring/bar 700 ms same; fades 200 ms; toast 300 ms; scan sweep 1.1 s linear.
Minimum tap target 44 px.

## 6. Assets
No image assets. All icons are inline SVG (back chevron, share, star, tab bar house / building / document-with-lock / vault / person, tick marks). Maps, the FMB sheet and document previews are **labelled placeholders** — real tiles, a cadastral layer and document thumbnails are needed. Fonts: Source Serif 4 (Google Fonts) for display; system sans for UI.

## 7. Files
- `Parcel Detail Redesign.dc.html` — the full interactive prototype (all three property types, all flows).
- `ios-frame.jsx` — device bezel used only to present the prototype; do not port.
